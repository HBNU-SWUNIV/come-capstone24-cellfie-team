package org.capstone.water.repository.entity.watertank;

/*
@AllArgsConstructor
@NoArgsConstructor
@Data
public class WaterId implements Serializable {
    private LocalDateTime dtime;

    @ManyToOne
    @JoinColumn(name = "fcid")
    private Watertank watertank;
}*/